
<?php
    $type = (empty($lab->id)) ? 'Add' : "Update";
    $page_title = 'Lab';
    $page_title_full = "$type $page_title";
?>
<?php $__env->startSection('page_title', "$page_title_full | " . config('app.name')); ?>
<?php $__env->startSection('content'); ?>
    <div class="pcoded-content">
        <?php echo $__env->make('franchisee.components.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="pcoded-inner-content">
            <div class="main-body">
                <div class="page-wrapper">
                    <div class="page-body">
                        <form method="POST" action="<?php echo e(route('franchisee.lab.addSubmit')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-7">
                                    <div class="card">
                                        <div class="card-header">
                                            <h5><?php echo e($page_title); ?> Details</h5>
                                        </div>
                                        <div class="card-block">
                                            <input type="hidden" name="id" value="<?php echo e($lab->id ?? ''); ?>">
                                            <div class="form-group row">
                                                <div class="col-sm-12">
                                                    <label class="float-label"><?php echo e($page_title); ?> Name</label>
                                                    <div class="input-group">
                                                        <span class="input-group-prepend">
                                                            <label class="input-group-text"><i
                                                                    class="fas fa-stethoscope"></i></label>
                                                        </span>
                                                        <input type="text" name="labname" id="labname" value="<?php echo e($lab->name ?? old('labname')); ?>" value=""
                                                            class="form-control" required="">
                                                    </div>
                                                </div>
                                                <div class="col-sm-12">
                                                    <label class="float-label">Address</label>
                                                    <textarea rows="3" cols="3" class="form-control" name="address" id="address" placeholder="Enter Address"><?php echo e($lab->address ?? old('address')); ?></textarea>
                                                    <span class="form-bar"></span>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-sm-12">
                                                    <button type="submit" name="formsubmission"
                                                        class="btn waves-effect waves-light btn-danger"><i
                                                            class="fas fa-sign-in-alt"></i> <?php echo e(empty($lab->id) ? 'Submit' : 'Update'); ?></button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('franchisee.components.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel projects\yogeshlabfranchisee\resources\views/franchisee/lab/add.blade.php ENDPATH**/ ?>