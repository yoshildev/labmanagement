
<?php
    $page_title = 'Lab';
    $page_title_full = "All $page_title";
?>
<?php $__env->startSection('page_title', "$page_title_full | " . config('app.name')); ?>
<?php $__env->startSection('content'); ?>
    <div class="pcoded-content">
        <?php echo $__env->make('franchisee.components.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="pcoded-inner-content">
            <div class="main-body">
                <div class="page-wrapper">
                    <div class="page-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h5><?php echo e($page_title); ?> List</h5>
                                    </div>
                                    <div class="card-block">
                                        <div class="dt-responsive table-responsive">
                                            <div id="scr-vtr-dynamic_wrapper"
                                                class="dataTables_wrapper dt-bootstrap4 no-footer">
                                                <div class="row">
                                                    <div class="col-xs-12 col-sm-12">
                                                        <table id="scr-vtr-dynamic"
                                                            class="table table-bordered nowrap dataTable no-footer">
                                                            <thead>
                                                                <tr style="background-color:#FFEEBA;" role="row">
                                                                    <th>#</th>
                                                                    <th>Lab Name</th>
                                                                    <th>Address </th>
                                                                    <th>Date Added</th>
                                                                    <th>Action </th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php $__empty_1 = true; $__currentLoopData = $labs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                <tr role="row" class="odd">
                                                                    <td><?php echo e($loop->iteration); ?></td>
                                                                    <td><?php echo e("$lab->name"); ?></td>
                                                                    <td><?php echo e($lab->address ?? null); ?></td>
                                                                    <td><?php echo e(date_format(date_create($lab->created_at),"d F , Y , h:i")); ?></td>
                                                                    <td>
                                                                    <a href="<?php echo e(route('franchisee.lab.update',['id'=>$lab->id])); ?>" class="btn waves-effect waves-light btn-info btn-icon">
                                                                    <label class="fas fa-edit"></label></a>
                                                                    <a href="<?php echo e(route('franchisee.lab.delete',['lab'=>$lab->id])); ?>"  class="d-none"></a>
                                                                        <a  onclick="openDeleteWarning(this)" class="btn waves-effect waves-light btn-danger btn-icon">
                                                                    
                                                                        <label class="fas fa-trash"></label></a>
                                                                    </td>
                                                                </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                    
                                                                <?php endif; ?>
                                                                
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('franchisee.components.datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('franchisee.components.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel projects\yogeshlabfranchisee\resources\views/franchisee/lab/all.blade.php ENDPATH**/ ?>