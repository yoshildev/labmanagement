
<?php
    $page_title = 'Doctors';
    $page_title_full = 'All Doctors';
?>
<?php $__env->startSection('page_title', "$page_title_full | " . config('app.name')); ?>
<?php $__env->startSection('content'); ?>
    <div class="pcoded-content">
        <?php echo $__env->make('franchisee.components.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="pcoded-inner-content">
            <div class="main-body">
                <div class="page-wrapper">
                    <div class="page-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h5>Doctors List</h5>
                                    </div>
                                    <div class="card-block">
                                        <div class="dt-responsive table-responsive">
                                            <div id="scr-vtr-dynamic_wrapper"
                                                class="dataTables_wrapper dt-bootstrap4 no-footer">
                                                <div class="row">
                                                    <div class="col-xs-12 col-sm-12">
                                                        <table id="scr-vtr-dynamic"
                                                            class="table table-bordered nowrap dataTable no-footer">
                                                            <thead>
                                                                <tr style="background-color:#FFEEBA;" role="row">
                                                                    <th>#</th>
                                                                    <th>Doctor Name</th>
                                                                    <th>Gender </th>
                                                                    <th> Specialization</th>
                                                                    <th>Address  </th>
                                                                    <th>Remarks</th>
                                                                    <th>Date Added</th>
                                                                    <th>Action </th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php $__empty_1 = true; $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                <tr role="row" class="odd">
                                                                    <td><?php echo e($loop->iteration); ?></td>
                                                                    <td><?php echo e("$doctor->first_name $doctor->last_name "); ?></td>
                                                                    <td><?php echo e($doctor->gender ?? null); ?><br><?php echo e($loop->dob ?? null); ?></td>
                                                                    <td><?php echo e($doctor->specialization ?? null); ?></td>
                                                                    <td><?php echo e($doctor->address ?? null); ?></td>
                                                                    <td><?php echo e($doctor->remark ?? null); ?></td>
                                                                    <td><?php echo e(date_format(date_create($doctor->created_at),"d F , Y , h:i")); ?></td>
                                                                    <td>
                                                                    <a href="<?php echo e(route('franchisee.doctor.update',['id'=>$doctor->id])); ?>" class="btn waves-effect waves-light btn-info btn-icon">
                                                                    <label class="fas fa-edit"></label></a>
                                                                    <a href="<?php echo e(route('franchisee.doctor.delete',['doctor'=>$doctor->id])); ?>"  class="d-none"></a>
                                                                    <a  onclick="openDeleteWarning(this)" class="btn waves-effect waves-light btn-danger btn-icon">
                                                                
                                                                    <label class="fas fa-trash"></label></a>
                                                                    </td>
                                                                </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                    
                                                                <?php endif; ?>
                                                                
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('franchisee.components.datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('franchisee.components.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel projects\yogeshlabfranchisee\resources\views/franchisee/doctor/all.blade.php ENDPATH**/ ?>