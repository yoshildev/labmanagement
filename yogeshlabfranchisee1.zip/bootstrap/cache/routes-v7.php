<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sanctum.csrf-cookie',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/health-check' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.healthCheck',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/execute-solution' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.executeSolution',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/update-config' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.updateConfig',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::niXTjUNfB5jEi6It',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/franchisee/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'franchisee.login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/franchisee/loginSubmit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'franchisee.loginSubmit',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/franchisee/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'franchisee.logout',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/franchisee/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'franchisee.dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/franchisee/doctor/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'franchisee.doctor.add',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/franchisee/doctor/addSubmit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'franchisee.doctor.addSubmit',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/franchisee/doctor/all' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'franchisee.doctor.all',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/franchisee/lab/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'franchisee.lab.add',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/franchisee/lab/addSubmit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'franchisee.lab.addSubmit',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/franchisee/lab/all' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'franchisee.lab.all',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/franchisee/sub-franchisee/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'franchisee.sub-franchisee.add',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/franchisee/sub-franchisee/addSubmit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'franchisee.sub-franchisee.addSubmit',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/franchisee/sub-franchisee/all' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'franchisee.sub-franchisee.all',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/franchisee/staff/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'franchisee.staff.add',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/franchisee/staff/addSubmit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'franchisee.staff.addSubmit',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/franchisee/staff/all' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'franchisee.staff.all',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/franchisee/(?|doctor/(?|update(?:/([^/]++))?(*:52)|delete(?:/([^/]++))?(*:79))|lab/(?|update(?:/([^/]++))?(*:114)|delete(?:/([^/]++))?(*:142))|s(?|ub\\-franchisee/update(?:/([^/]++))?(*:190)|taff/update(?:/([^/]++))?(*:223))))/?$}sDu',
    ),
    3 => 
    array (
      52 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'franchisee.doctor.update',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      79 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'franchisee.doctor.delete',
            'doctor' => NULL,
          ),
          1 => 
          array (
            0 => 'doctor',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      114 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'franchisee.lab.update',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      142 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'franchisee.lab.delete',
            'lab' => NULL,
          ),
          1 => 
          array (
            0 => 'lab',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      190 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'franchisee.sub-franchisee.update',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      223 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'franchisee.staff.update',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'sanctum.csrf-cookie' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'sanctum.csrf-cookie',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.healthCheck' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_ignition/health-check',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController',
        'as' => 'ignition.healthCheck',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.executeSolution' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/execute-solution',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController',
        'as' => 'ignition.executeSolution',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.updateConfig' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/update-config',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController',
        'as' => 'ignition.updateConfig',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::niXTjUNfB5jEi6It' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:77:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000005180000000000000000";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::niXTjUNfB5jEi6It',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'franchisee.login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'franchisee/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Franchisee.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\FranchiseeController@login',
        'controller' => 'App\\Http\\Controllers\\FranchiseeController@login',
        'as' => 'franchisee.login',
        'namespace' => NULL,
        'prefix' => '/franchisee',
        'where' => 
        array (
        ),
        'excluded_middleware' => 
        array (
          0 => 'Franchisee.auth',
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'franchisee.loginSubmit' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'franchisee/loginSubmit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Franchisee.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\FranchiseeController@loginSubmit',
        'controller' => 'App\\Http\\Controllers\\FranchiseeController@loginSubmit',
        'as' => 'franchisee.loginSubmit',
        'namespace' => NULL,
        'prefix' => '/franchisee',
        'where' => 
        array (
        ),
        'excluded_middleware' => 
        array (
          0 => 'Franchisee.auth',
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'franchisee.logout' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'franchisee/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Franchisee.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\FranchiseeController@logout',
        'controller' => 'App\\Http\\Controllers\\FranchiseeController@logout',
        'as' => 'franchisee.logout',
        'namespace' => NULL,
        'prefix' => '/franchisee',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'franchisee.dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'franchisee/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Franchisee.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\FranchiseeController@dashboard',
        'controller' => 'App\\Http\\Controllers\\FranchiseeController@dashboard',
        'as' => 'franchisee.dashboard',
        'namespace' => NULL,
        'prefix' => '/franchisee',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'franchisee.doctor.add' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'franchisee/doctor/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Franchisee.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\DoctorController@add',
        'controller' => 'App\\Http\\Controllers\\DoctorController@add',
        'as' => 'franchisee.doctor.add',
        'namespace' => NULL,
        'prefix' => 'franchisee/doctor',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'franchisee.doctor.update' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'franchisee/doctor/update/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Franchisee.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\DoctorController@add',
        'controller' => 'App\\Http\\Controllers\\DoctorController@add',
        'as' => 'franchisee.doctor.update',
        'namespace' => NULL,
        'prefix' => 'franchisee/doctor',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'franchisee.doctor.delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'franchisee/doctor/delete/{doctor?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Franchisee.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\DoctorController@delete',
        'controller' => 'App\\Http\\Controllers\\DoctorController@delete',
        'as' => 'franchisee.doctor.delete',
        'namespace' => NULL,
        'prefix' => 'franchisee/doctor',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'franchisee.doctor.addSubmit' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'franchisee/doctor/addSubmit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Franchisee.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\DoctorController@addSubmit',
        'controller' => 'App\\Http\\Controllers\\DoctorController@addSubmit',
        'as' => 'franchisee.doctor.addSubmit',
        'namespace' => NULL,
        'prefix' => 'franchisee/doctor',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'franchisee.doctor.all' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'franchisee/doctor/all',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Franchisee.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\DoctorController@all',
        'controller' => 'App\\Http\\Controllers\\DoctorController@all',
        'as' => 'franchisee.doctor.all',
        'namespace' => NULL,
        'prefix' => 'franchisee/doctor',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'franchisee.lab.add' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'franchisee/lab/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Franchisee.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\LabController@add',
        'controller' => 'App\\Http\\Controllers\\LabController@add',
        'as' => 'franchisee.lab.add',
        'namespace' => NULL,
        'prefix' => 'franchisee/lab',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'franchisee.lab.update' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'franchisee/lab/update/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Franchisee.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\LabController@add',
        'controller' => 'App\\Http\\Controllers\\LabController@add',
        'as' => 'franchisee.lab.update',
        'namespace' => NULL,
        'prefix' => 'franchisee/lab',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'franchisee.lab.delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'franchisee/lab/delete/{lab?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Franchisee.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\LabController@delete',
        'controller' => 'App\\Http\\Controllers\\LabController@delete',
        'as' => 'franchisee.lab.delete',
        'namespace' => NULL,
        'prefix' => 'franchisee/lab',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'franchisee.lab.addSubmit' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'franchisee/lab/addSubmit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Franchisee.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\LabController@addSubmit',
        'controller' => 'App\\Http\\Controllers\\LabController@addSubmit',
        'as' => 'franchisee.lab.addSubmit',
        'namespace' => NULL,
        'prefix' => 'franchisee/lab',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'franchisee.lab.all' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'franchisee/lab/all',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Franchisee.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\LabController@all',
        'controller' => 'App\\Http\\Controllers\\LabController@all',
        'as' => 'franchisee.lab.all',
        'namespace' => NULL,
        'prefix' => 'franchisee/lab',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'franchisee.sub-franchisee.add' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'franchisee/sub-franchisee/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Franchisee.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\FranchiseeController@add',
        'controller' => 'App\\Http\\Controllers\\FranchiseeController@add',
        'as' => 'franchisee.sub-franchisee.add',
        'namespace' => NULL,
        'prefix' => 'franchisee/sub-franchisee',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'franchisee.sub-franchisee.update' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'franchisee/sub-franchisee/update/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Franchisee.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\FranchiseeController@add',
        'controller' => 'App\\Http\\Controllers\\FranchiseeController@add',
        'as' => 'franchisee.sub-franchisee.update',
        'namespace' => NULL,
        'prefix' => 'franchisee/sub-franchisee',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'franchisee.sub-franchisee.addSubmit' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'franchisee/sub-franchisee/addSubmit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Franchisee.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\FranchiseeController@addSubmit',
        'controller' => 'App\\Http\\Controllers\\FranchiseeController@addSubmit',
        'as' => 'franchisee.sub-franchisee.addSubmit',
        'namespace' => NULL,
        'prefix' => 'franchisee/sub-franchisee',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'franchisee.sub-franchisee.all' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'franchisee/sub-franchisee/all',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Franchisee.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\FranchiseeController@all',
        'controller' => 'App\\Http\\Controllers\\FranchiseeController@all',
        'as' => 'franchisee.sub-franchisee.all',
        'namespace' => NULL,
        'prefix' => 'franchisee/sub-franchisee',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'franchisee.staff.add' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'franchisee/staff/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Franchisee.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\StaffController@add',
        'controller' => 'App\\Http\\Controllers\\StaffController@add',
        'as' => 'franchisee.staff.add',
        'namespace' => NULL,
        'prefix' => 'franchisee/staff',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'franchisee.staff.update' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'franchisee/staff/update/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Franchisee.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\StaffController@add',
        'controller' => 'App\\Http\\Controllers\\StaffController@add',
        'as' => 'franchisee.staff.update',
        'namespace' => NULL,
        'prefix' => 'franchisee/staff',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'franchisee.staff.addSubmit' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'franchisee/staff/addSubmit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Franchisee.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\StaffController@addSubmit',
        'controller' => 'App\\Http\\Controllers\\StaffController@addSubmit',
        'as' => 'franchisee.staff.addSubmit',
        'namespace' => NULL,
        'prefix' => 'franchisee/staff',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'franchisee.staff.all' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'franchisee/staff/all',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Franchisee.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\StaffController@all',
        'controller' => 'App\\Http\\Controllers\\StaffController@all',
        'as' => 'franchisee.staff.all',
        'namespace' => NULL,
        'prefix' => 'franchisee/staff',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
