<link rel="stylesheet" href="{{ asset('franchisee_assets/bower_components/select2/css/select2.min.css') }}?v=1.1" />
<script type="text/javascript"
    src="{{ asset('franchisee_assets/bower_components/select2/js/select2.full.min.js') }}?v=1.1"></script>'

<script>
    $(document).ready(function() {
        $('.select2').select2();
    });
</script>
