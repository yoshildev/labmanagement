<?php

namespace App\Livewire;

use Livewire\Component;

class Testing extends Component
{
    public function render()
    {
        return view('livewire.testing');
    }
}
