
<?php
    $page_title = 'Request Stock';
    $page_title_full = " $page_title";
?>
<?php $__env->startSection('page_title', "$page_title_full | " . config('app.name')); ?>
<?php $__env->startSection('content'); ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

    <div class="pcoded-content">
        <?php echo $__env->make('franchisee.components.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="pcoded-inner-content">
            <div class="main-body">
                <div class="page-wrapper">
                    <div class="page-body">
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('franchisee.Inventory.RequestStock');

$__html = app('livewire')->mount($__name, $__params, 'Ly6tLcw', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            $('#selectfranchisee option').each(function() {
                $(this).text($(this).text().toUpperCase());
            });
        });
    </script>
    <?php echo $__env->make('franchisee.components.select2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('franchisee.components.select2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('franchisee.components.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel projects\yogeshlabfranchisee\resources\views/franchisee/inventory/requestStock.blade.php ENDPATH**/ ?>