
<?php
    // $type = empty($staff->id) ? 'Add' : 'Update';
    $page_title = 'Online Payments';
    $page_title_full = "$page_title";
?>
<?php $__env->startSection('page_title', "$page_title_full | " . config('app.name')); ?>
<?php $__env->startSection('content'); ?>
    <div class="pcoded-content">
        <?php echo $__env->make('franchisee.components.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="pcoded-inner-content">
            <div class="main-body">
                <div class="page-wrapper">
                    <div class="page-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h5>Select Payment Mode</h5>
                                    </div>
                                    <div class="card-block" id="franchiseedetails">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <a href="<?php echo e(route('franchisee.credits.addCredit')); ?>">
                                                    <img alt="Razor Pay"
                                                        src="<?php echo e(asset('franchisee_assets/online/pg_razor_pay.png')); ?>"
                                                        style="width:200px">
                                                </a>
                                            </div>
                                        </div>
                                        <br><hr><br>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('franchisee.components.select2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('franchisee.components.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel projects\yogeshlabfranchisee\resources\views/franchisee/credits/add.blade.php ENDPATH**/ ?>