<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<style>
    .swal2-popup {
        z-index: 9999999 !important;
    }
    aside {
        z-index: 999999 !important;
    }
    .swal2-container {
        z-index: 999999 !important;
    }
    .layout-navbar-fixed body:not(.modal-open) .layout-content-navbar .layout-navbar,
    .layout-menu-fixed body:not(.modal-open) .layout-content-navbar .layout-navbar,
    .layout-menu-fixed-offcanvas body:not(.modal-open) .layout-content-navbar .layout-navbar {
        /* z-index: 999999 !important; */
        /* z-index: 50 !important; */
    }
</style>
<script>
    $(document).ready(function() {
        <?php if(session()->has('success')): ?>
            Swal.fire({
                position: 'top-end',
                icon: 'success',
                toast: true,
                title: '<?php echo e(session('success')); ?>',
                showConfirmButton: false,
                timer: 4500
            })
        <?php endif; ?>
        <?php if(session()->has('errors')): ?>
            Swal.fire({
                position: 'top-end',
                toast: true,
                icon: 'error',
                html: `<ul>
                <?php $__currentLoopData = session('errors')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>`,
                showConfirmButton: false,
                timer: 15500
            })
        <?php endif; ?>
    });
</script>
<script>
    const openDeleteWarning = (e) => {
        // console.log(e.previousElementSibling)
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                Swal.fire(
                    'Deleted!',
                    'Your file has been deleted.',
                    'success'
                )
                e.previousElementSibling.click();
            }
        })
    }
    const success = (message) => {
        Swal.fire({
            position: 'top-end',
            icon: 'success',
            toast: true,
            title: `${message}`,
            showConfirmButton: false,
            timer: 4500
        })
    }
    const error = (message) => {
        Swal.fire({
            position: 'top-end',
            icon: 'error',
            toast: true,
            title: `${message}`,
            showConfirmButton: false,
            timer: 4500
        })
    }
</script>

<?php /**PATH C:\laravel projects\yogeshlabfranchisee\resources\views/franchisee/components/messages.blade.php ENDPATH**/ ?>