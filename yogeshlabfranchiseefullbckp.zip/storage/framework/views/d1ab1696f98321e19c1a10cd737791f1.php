<link rel="stylesheet" href="<?php echo e(asset('franchisee_assets/bower_components/select2/css/select2.min.css')); ?>?v=1.1" />
<script type="text/javascript"
    src="<?php echo e(asset('franchisee_assets/bower_components/select2/js/select2.full.min.js')); ?>?v=1.1"></script>'

<script>
    $(document).ready(function() {
        $('.select2').select2();
    });
</script>


<?php /**PATH C:\laravel projects\yogeshlabfranchisee\resources\views/franchisee/components/select2.blade.php ENDPATH**/ ?>