@extends('franchisee.components.layout')
@section('page_title', "Dashboard | {{ config('app.name') }}")
@section('content')
@php
$page_title = "Doctor";
$page_title_full = "Add Doctor";
@endphp
    <div class="pcoded-content">
        @include('franchisee.components.breadcrumb')
        <div class="pcoded-inner-content">
            <div class="main-body">
                <div class="page-wrapper">
                    <div class="page-body">
                        <form method="POST" action="add">
                            <div class="row">
                                <div class="col-md-5">
                                    <div class="card">
                                        <div class="card-header">
                                            <h5>{{$page_title}} Information</h5>
                                        </div>
                                        <div class="card-block">
                                            <div class="form-group row">
                                                <div class="col-sm-12">
                                                    <label class="float-label">Firstname *</label>
                                                    <div class="input-group">
                                                        <span class="input-group-prepend">
                                                            <label class="input-group-text"><i
                                                                    class="fas fa-user"></i></label>
                                                        </span>
                                                        <input type="text" name="firstname" id="firstname" value=""
                                                            class="form-control" required="">
                                                    </div>
                                                </div>
                                                <div class="col-sm-12">
                                                    <label class="float-label">Lastname *</label>
                                                    <div class="input-group">
                                                        <span class="input-group-prepend">
                                                            <label class="input-group-text"><i
                                                                    class="fas fa-user"></i></label>
                                                        </span>
                                                        <input type="text" name="lastname" id="lastname" value=""
                                                            class="form-control" required="">
                                                    </div>
                                                </div>
                                                <div class="col-sm-12">
                                                    <label class="float-label">Date of Birth</label>
                                                    <div class="input-group">
                                                        <span class="input-group-prepend">
                                                            <label class="input-group-text"><i
                                                                    class="fa fa-calendar"></i></label>
                                                        </span>
                                                        <input class="form-control fill" name="dob" id="dob"
                                                            type="text" placeholder="" value="1995-01-01">
                                                    </div>
                                                </div>
                                                <div class="col-sm-12">
                                                    <label class="float-label">Gender</label>
                                                    <select class="js-example-basic-single select2-hidden-accessible"
                                                        name="gender" tabindex="-1" aria-hidden="true">
                                                        <option value="male">Male</option>
                                                        <option value="female">Female</option>
                                                    </select><span
                                                        class="select2 select2-container select2-container--default select2-container--below"
                                                        dir="ltr" style="width: 71.2px;"><span class="selection"><span
                                                                class="select2-selection select2-selection--single"
                                                                role="combobox" aria-haspopup="true" aria-expanded="false"
                                                                tabindex="0"
                                                                aria-labelledby="select2-gender-yr-container"><span
                                                                    class="select2-selection__rendered"
                                                                    id="select2-gender-yr-container"
                                                                    title="Male">Male</span><span
                                                                    class="select2-selection__arrow" role="presentation"><b
                                                                        role="presentation"></b></span></span></span><span
                                                            class="dropdown-wrapper" aria-hidden="true"></span></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-7">
                                    <div class="card">
                                        <div class="card-header">
                                            <h5>Professional Details</h5>
                                        </div>
                                        <div class="card-block">
                                            <div class="form-group row">
                                                <div class="col-sm-12">
                                                    <label class="float-label">Doctor Specialization *</label>
                                                    <div class="input-group">
                                                        <span class="input-group-prepend">
                                                            <label class="input-group-text"><i
                                                                    class="fas fa-stethoscope"></i></label>
                                                        </span>
                                                        <input type="text" name="specialization" id="specialization"
                                                            value="" class="form-control" required="">
                                                    </div>
                                                </div>
                                                <div class="col-sm-12">
                                                    <label class="float-label">Remarks</label>
                                                    <textarea rows="3" cols="3" class="form-control" name="remarks" id="remarks"
                                                        placeholder="Enter Remarks"></textarea>
                                                    <span class="form-bar"></span>
                                                </div>
                                                <div class="col-sm-12"><br>
                                                    <label class="float-label">Address</label>
                                                    <textarea rows="3" cols="3" class="form-control" name="address" id="address"
                                                        placeholder="Enter Address Details"></textarea>
                                                    <span class="form-bar"></span>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-sm-12">
                                                    <button type="submit" name="formsubmission"
                                                        class="btn waves-effect waves-light btn-danger"><i
                                                            class="fas fa-sign-in-alt"></i> Submit</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
