<?php
namespace App\Http\Controllers;
use App\Models\Franchisee;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use function Ramsey\Uuid\v1;
class FranchiseeController extends Controller
{
    public function login (){
        return view('franchisee.auth.login');
    }
    public function loginSubmit (Request $r){
        $r->validate([
            'username' => 'required|exists:franchisees,username',
            'password' => 'required'    
        ]);
        $franchisee = Franchisee::where('username',$r->username)->first();
        if ($franchisee) {
            if (Hash::check($r->password,$franchisee->password)) {
                Session::put('FRANCHISEE_ID',$franchisee->id);
                return to_route('franchisee.dashboard');
            }else {
                return error('Incorrect Passowrd');
            }
        }else {
            return error('No Username Found With This Username');
        }
    }
    public function logout(){
        Session::flush();
        return to_route('franchisee.login');
    }
    public function dashboard(){
        return view('franchisee.dashboard');
    }
}
