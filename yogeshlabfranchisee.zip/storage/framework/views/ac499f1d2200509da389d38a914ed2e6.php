<nav class="navbar header-navbar pcoded-header">
    <div class="navbar-wrapper">
        <div class="navbar-logo">
            <a href="https://hypatholab.com/crm/franchisee">
                <img class="img-fluid" src="<?php echo e(asset('franchisee_assets/logo/logo.png')); ?>"
                    width="160px" alt="Hypatholab" />
            </a>
            <a class="mobile-menu" id="mobile-collapse" href="#!">
                <i class="feather icon-menu"></i>
            </a>
            <a class="mobile-options waves-effect waves-light">
                <i class="feather icon-more-horizontal"></i>
            </a>
        </div>
        <div class="navbar-container container-fluid">
            <ul class="nav-left">
                <li>
                    <a href="#!" onclick="javascript:toggleFullScreen()"
                        class="waves-effect waves-light">
                        <i class="full-screen feather icon-maximize"></i>
                    </a>
                </li>
                <li class="header-search">
                    <form method="GET"
                        action="https://hypatholab.com/crm/franchisee/booking/searchbooking"
                        enctype="multipart/form-data">
                        <div class="main-search morphsearch-search">
                            <div class="input-group">
                                <span class="input-group-prepend search-close">
                                    <i class="feather icon-x input-group-text"></i>
                                </span>
                                <input type="text" name="keywordq" class="form-control"
                                    placeholder="Enter Keyword">
                                <span class="input-group-append search-btn">
                                    <i class="feather icon-search input-group-text"></i>
                                </span>
                            </div>
                        </div>
                    </form>
                </li>
                <li>
                    <span class="text-danger font-weight-bold">Credits : <?php echo e($franchiseeDetails->credits); ?></span>
                </li>
                <li>
                    <a href="#" onclick="showTestPortfolio('FR000007')"
                        class="waves-effect waves-light">
                        <i class="fa fa-clipboard"></i>
                    </a>
                </li>
                <li style="padding: 0px;">
                    <a href="https://hypatholab.com/crm/franchisee/online/payments"
                        style="font-size: 12px;padding-top: 8px;color: #eb994a;font-weight: 800;"
                        class="waves-effect waves-light">
                        <i class="fa fa-rupee-sign"></i> Online Payment
                    </a>
                </li>
            </ul>
            <ul class="nav-right">
                <li class="header-notification">
                    <div class="dropdown-primary dropdown">
                        <div class="dropdown-toggle" data-toggle="dropdown">
                            <i class="fa fa-user"></i>
                            <span class="badge bg-c-red">5</span>
                        </div>
                        <ul class="show-notification notification-view dropdown-menu"
                            data-dropdown-in="fadeIn" data-dropdown-out="fadeOut">
                            <li>
                                <h6>Welcome to <?php echo e(config('app.name')); ?>!</h6>
                                <label class="label label-danger"><?php echo e(date("Y")); ?></label>
                            </li>
                            <li>
                                <div class="media">
                                    <!--<img class="img-radius" src="<?php echo e(asset('franchisee_assets/assets/images/avatar-4.jpg')); ?>" alt="Generic placeholder image">-->
                                    <div class="media-body">
                                        <h5 class="notification-user">HY PATHO LAB .</h5>
                                        <p class="notification-msg">Username : <?php echo e($franchiseeDetails->username); ?></p>
                                        <span class="notification-time">ID : <?php echo e(franchiseeId($franchiseeDetails->id)); ?></span>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </li>
                <li class="header-notification customerCareNav">
                    <div class="dropdown-primary dropdown">
                        <div class="dropdown-toggle text-primary font-weight-bold" data-toggle="dropdown">
                            <i class="fa fa-headphones"></i> Customer Care
                            <span class="badge bg-c-red"></span>
                        </div>
                        <ul class="show-notification notification-view dropdown-menu"
                            data-dropdown-in="fadeIn" data-dropdown-out="fadeOut">
                            <li>
                                <h6>Helpline & Support</h6>
                                <label class="label label-danger"><i class="fa fa-headphones"></i>
                                    24X7</label>
                            </li>
                            <li>
                                <div class="media">
                                    <!--<img class="img-radius" src="<?php echo e(asset('franchisee_assets/assets/images/avatar-4.jpg')); ?>" alt="Generic placeholder image">-->
                                    <div class="media-body">
                                        <?php if(!empty(customerCareNumber())): ?>
                                        <h5 class="notification-user"><i class="fa fa-phone"></i> Customer
                                            Care (24X7)<br />+91 <?php echo e(customerCareNumber()); ?></h5><br />
                                        <?php endif; ?>
                                        <?php if(!empty(helpDeskNumber())): ?>
                                        <h5 class="notification-user"><i class="fa fa-phone"></i>Helpdesk
                                            (7AM - 7PM)<br />+91 <?php echo e(helpDeskNumber()); ?></h5>
                                        <?php endif; ?>
                                        <hr />
                                       <?php echo bankAccountDetails(); ?>

                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </li>
                <li class="user-profile header-notification">
                    <div class="dropdown-primary dropdown">
                        <div class="dropdown-toggle font-weight-bold text-danger" data-toggle="dropdown">
                            <i class="fa fa-power-off"></i>
                        </div>
                        <ul class="show-notification profile-notification dropdown-menu"
                            data-dropdown-in="fadeIn" data-dropdown-out="fadeOut">
                            <li class="drp-u-details">
                                <img src="https://cdn-icons-png.flaticon.com/512/219/219959.png"
                                    class="img-radius" alt="<?php echo e(labName()); ?>  .">
                                <span><?php echo e(labName()); ?> .</span>
                                <a href="<?php echo e(route('franchisee.logout')); ?>" class="dud-logout"
                                    title="Logout">
                                    <i class="feather icon-log-out"></i>
                                </a>
                            </li>
                            <li>
                                <a href="settings/changedetails">
                                    <i class="feather icon-settings"></i> Settings
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('franchisee.logout')); ?>">
                                    <i class="feather icon-log-out"></i> Logout
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</nav><?php /**PATH C:\laravel projects\yogeshlabfranchisee\resources\views/franchisee/components/header.blade.php ENDPATH**/ ?>